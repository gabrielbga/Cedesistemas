package models;

public class Comedia extends Pelicula{
    public String genrer;

    public Comedia() {

    }

    public Comedia(String adult, String originalLanguage, String originalTitle, String overview, String time, String budget, String genrer) {
        super(adult, originalLanguage, originalTitle, overview, time, budget);
        this.genrer = genrer;
    }

    public String getGenrer() {
        return genrer;
    }

    public void setGenrer(String genrer) {
        this.genrer = genrer;
    }
}
