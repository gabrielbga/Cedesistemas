package resources;

import models.Drama;
import models.Suspenso;

import java.util.ArrayList;
import java.util.Locale;

public class SuspensoMethods {
    public static ArrayList<Suspenso> addT(ArrayList<Suspenso> suspenso) {

        for (int i = 0; i < suspenso.size(); i++) {
            suspenso.get(i).setAdult(suspenso.get(i).getAdult());
            suspenso.get(i).setOriginalLanguage(suspenso.get(i).getOriginalLanguage());
            suspenso.get(i).setOriginalTitle(suspenso.get(i).getOriginalTitle());
            suspenso.get(i).setOverview(suspenso.get(i).getOverview());
            suspenso.get(i).setTime(suspenso.get(i).getTime());
            suspenso.get(i).setBudget(suspenso.get(i).getBudget());
            suspenso.get(i).setGenrer(suspenso.get(i).getGenrer());
        }

        return suspenso;
    }


    public static ArrayList<Suspenso> modSuspenso(ArrayList<Suspenso> suspenso) {
        for (int i = 0; i < suspenso.size(); i++) {
            String opcion = Lecutra.escaneoString("Hay " + (i + 1) +" peliculas, " + "QUIERE modificar la pelicula?" + (i + 1) + " DIGITE S o N");
            if (opcion.toLowerCase(Locale.ROOT).equals("s")) {
                suspenso.get(i).setAdult(Lecutra.escaneoString("digite el valor de si es true o false +18"));
                suspenso.get(i).setOriginalLanguage(Lecutra.escaneoString("digite el valor language"));
                suspenso.get(i).setOriginalTitle(Lecutra.escaneoString("digite el valor title"));
                suspenso.get(i).setOverview(Lecutra.escaneoString("digite el valor"));
                suspenso.get(i).setTime(Lecutra.escaneoString("digite el valor time"));
                suspenso.get(i).setBudget(Lecutra.escaneoString("digite el valor BUDGET"));
                suspenso.get(i).setGenrer(Lecutra.escaneoString("digite el valor genrer"));
            }
        }
        return suspenso;
    }


    static String time = null;
    static String name = null;

    public static void obtenerTiempoSuspenso(ArrayList<Suspenso> suspenso) {
        String name = null;

        for (int i = 0; i < suspenso.size(); i++) {
            time = suspenso.get(i).getTime();
            name = suspenso.get(i).getOriginalTitle();
        }
        System.out.println((Constants.TITULO + name +  " con duracion : " + time));

    }

    public static void obtenerDescripcionSuspenso(ArrayList<Suspenso> suspenso) {
        String overview = null;


        for (int i = 0; i < suspenso.size(); i++) {
            name = suspenso.get(i).getOriginalTitle();
            overview = suspenso.get(i).getOverview();
        }

    }
}
