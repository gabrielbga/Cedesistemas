package resources;

import models.Drama;


import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class DramaMenu {
    public static void menuDrama() {

        ArrayList<Drama> dramas = new ArrayList<>();
        dramas.add(new Drama("true", "DE", "El pianista", "El pianista esta basada en la vida de wladislaw szpilman"
                , "320min", "1000000$", "Drama"));
        Scanner lector = new Scanner(System.in);
        System.out.println(" Selecciona una opcion ");
        boolean salir = false;
        int opcion;
        while (!salir) {
            System.out.println("1. Opcion Informacion");
            System.out.println("2. Opcion Actualizar");
            System.out.println("3. Opcion Mostrar duracion peliculas");
            System.out.println("4. Opcion Mostrar resumen pelicula");
            System.out.println("5. Opcion Recomendaciones");
            System.out.println("6. Salir");

            try {

                opcion = lector.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.println("Opcion Informacion");

                        obtenerInformacionDrama(DramaMethods.addT(dramas));
                        break;
                    case 2:
                        System.out.println("Opcion Actualizar");
                        DramaMethods.modDrama(dramas);
                        break;
                    case 3:
                        System.out.println("Opcion Mostrar duracion peliculas");
                       DramaMethods.obtenerTiempoDrama(dramas);
                        break;
                    case 4:
                        System.out.println("Opcion Mostrar resumen pelicula");
                       DramaMethods.obtenerDescripcion(dramas);
                        break;
                    case 5:
                        System.out.println("Como consejo , ya que es de Drama debe reproducirse a 0.9x");
                        break;
                    case 6:
                        System.out.println("Salir");
                        salir = true;
                        break;
                    default:
                        System.out.println("digita los numeros entre 1 y 4");
                }
            } catch (InputMismatchException e) {
                System.out.println("Digite un numero del 1 al 4");
                lector.next();
            }
        }
    }

    public static void obtenerInformacionDrama(ArrayList<Drama> dramas) {


        for (int i = 0; i < dramas.size(); i++) {

                System.out.println(Constants.ADULT + dramas.get(i).getAdult() + Constants.IDIOMA + dramas.get(i).getOriginalLanguage() + Constants.TITULO + dramas.get(i).getOriginalTitle() +
                        Constants.DESCRIPCION + dramas.get(i).getOverview() + Constants.DURACION + dramas.get(i).getTime() + Constants.PRESUPUESTO + dramas.get(i).getBudget() + Constants.GENERO + dramas.get(i).getGenrer());

        }
    }
}
