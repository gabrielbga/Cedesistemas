package resources;

public class Constants {
    public static final String  ADULT="Es para adultos? :";
    public static final String  IDIOMA=" ,IDIOMA :";
    public static final String  TITULO=" ,Titulo :";
    public static final String  DESCRIPCION=" ,Descripcion :";
    public static final String  DURACION   =" ,Duracion :";
    public static final String  PRESUPUESTO=" ,Presupuesto :";
    public static final String  GENERO=" ,Genero :";
    public static final String  NOMBRE_PELICULA="el nombre de la pelicula es ";
    public static final String  OVERVIEW= " con overviem ";

}
