package resources;

import models.Terror;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class TerrorMenu {
    public static void menuTerror() {
        ArrayList<Terror> terror = new ArrayList<>();
        terror.add(new Terror("true", "es", "El grito", "The Grudge es el título de una saga de películas de terror estadounidenses producida por Ghost House Pictures y distribuida por Columbia Pictures, basada en la saga japonesa Ju-on"
                , "120min", "500000$", "Terror"));
        terror.add(new Terror("false", "es", "Maligno ", "Maligno trata de ..."
                , "240min", "800000$", "Terror"));
        Scanner lector = new Scanner(System.in);
        System.out.println(" Selecciona una opcion ");
        boolean salir = false;
        int opcion;
        while (!salir) {
            System.out.println("1. Opcion Informacion");
            System.out.println("2. Opcion Actualizar");
            System.out.println("3. Opcion Mostrar duracion peliculas");
            System.out.println("4. Opcion Mostrar resumen pelicula");
            System.out.println("5. Opcion Recomendaciones");
            System.out.println("6. Salir");

            try {

                opcion = lector.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.println("Opcion Informacion");

                        obtenerInformacion(PeliculasAdd.addT(terror));
                        break;
                    case 2:
                        System.out.println("Opcion Actualizar");
                        PeliculasAdd.modTerror(terror);
                        break;
                    case 3:
                        System.out.println("Opcion Mostrar duracion peliculas");
                        PeliculasAdd.obtenerTiempo(terror);
                        break;
                    case 4:
                        System.out.println("Opcion Mostrar resumen pelicula");
                        PeliculasAdd.obtenerDescripcion(terror);
                        break;
                    case 5:
                        System.out.println("Como consejo , ya que es de terror debe reproducirse a 1.2x");
                        break;
                    case 6:
                        System.out.println("Salir");
                        salir = true;
                        break;
                    default:
                        System.out.println("digita los numeros entre 1 y 4");
                }
            } catch (InputMismatchException e) {
                System.out.println("Digite un numero del 1 al 4");
                lector.next();
            }
        }
    }

    public static void obtenerInformacion(ArrayList<Terror> terrors) {


        for (int i = 0; i < terrors.size(); i++)

                System.out.println(Constants.ADULT+terrors.get(i).getAdult() + Constants.IDIOMA+terrors.get(i).getOriginalLanguage() + Constants.TITULO+terrors.get(i).getOriginalTitle()+
                        Constants.DESCRIPCION + terrors.get(i).getOverview() + Constants.DURACION +terrors.get(i).getTime() + Constants.PRESUPUESTO+terrors.get(i).getBudget() + Constants.GENERO+terrors.get(i).getGenrer());
    }
}


