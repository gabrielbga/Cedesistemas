package resources;

import models.Comedia;

import java.util.ArrayList;
import java.util.Locale;

public class ComediaMethods {

    public static ArrayList<Comedia> addT(ArrayList<Comedia> comedia) {

        for (int i = 0; i < comedia.size(); i++) {
            comedia.get(i).setAdult(comedia.get(i).getAdult());
            comedia.get(i).setOriginalLanguage(comedia.get(i).getOriginalLanguage());
            comedia.get(i).setOriginalTitle(comedia.get(i).getOriginalTitle());
            comedia.get(i).setOverview(comedia.get(i).getOverview());
            comedia.get(i).setTime(comedia.get(i).getTime());
            comedia.get(i).setBudget(comedia.get(i).getBudget());
            comedia.get(i).setGenrer(comedia.get(i).getGenrer());
        }

        return comedia;
    }


    public static ArrayList<Comedia> modComedia(ArrayList<Comedia> comedia) {
        for (int i = 0; i < comedia.size(); i++) {
            String opcion = Lecutra.escaneoString("Hay " + (i + 1) + " peliculas, " + "QUIERE modificar la pelicula?" + (i + 1) + " DIGITE S o N");
            if (opcion.toLowerCase(Locale.ROOT).equals("s")) {
                comedia.get(i).setAdult(Lecutra.escaneoString("digite el valor de si es true o false +18"));
                comedia.get(i).setOriginalLanguage(Lecutra.escaneoString("digite el valor language"));
                comedia.get(i).setOriginalTitle(Lecutra.escaneoString("digite el valor title"));
                comedia.get(i).setOverview(Lecutra.escaneoString("digite el valor ed overview "));
                comedia.get(i).setTime(Lecutra.escaneoString("digite el valor time"));
                comedia.get(i).setBudget(Lecutra.escaneoString("digite el valor BUDGET"));
                comedia.get(i).setGenrer(Lecutra.escaneoString("digite el valor genrer"));

            }
        }
        return comedia;
    }


    static String time = null;
    static String name = null;

    public static void obtenerTiempo(ArrayList<Comedia> comedia) {


        for (int i = 0; i < comedia.size(); i++) {
            time = comedia.get(i).getTime();
            name = comedia.get(i).getOriginalTitle();
            System.out.println("el nombre de la pelicula es :" + name + " con duracion :" + time);
        }
    }

    public static void obtenerDescripcion(ArrayList<Comedia> comedia) {
        String overview = null;


        for (int i = 0; i < comedia.size(); i++) {
            System.out.println(i);
            name = comedia.get(i).getOriginalTitle();
            overview = comedia.get(i).getOverview();
            System.out.println((Constants.TITULO + name + Constants.OVERVIEW + overview));
        }
    }
}
