package resources;

import models.Terror;

import java.util.ArrayList;
import java.util.Locale;

public class PeliculasAdd {


    public static void addTerror(Terror terror) {

        String opcion = Lecutra.escaneoString("QUIERE AGREGAR PELICULA? DIGITE S o N");
        if (opcion.toLowerCase(Locale.ROOT) == "s") {
            terror.setAdult(Lecutra.escaneoString("digite el valor"));
            terror.setOriginalLanguage(Lecutra.escaneoString("digite el valor language"));
            terror.setOriginalTitle(Lecutra.escaneoString("digite el valor title"));
            terror.setOverview(Lecutra.escaneoString("digite el valor"));
            terror.setTime(Lecutra.escaneoString("digite el valor time"));
            terror.setBudget(Lecutra.escaneoString("digite el valor BUDGET"));
            terror.setGenrer(Lecutra.escaneoString("digite el valor genrer"));


        }


    }


    static ArrayList<Terror> terror = new ArrayList<>();

    public static ArrayList<Terror> addT(ArrayList<Terror> terror) {

        for (int i = 0; i < terror.size(); i++) {
            terror.get(i).setAdult(terror.get(i).getAdult());
            terror.get(i).setOriginalLanguage(terror.get(i).getOriginalLanguage());
            terror.get(i).setOriginalTitle(terror.get(i).getOriginalTitle());
            terror.get(i).setOverview(terror.get(i).getOverview());
            terror.get(i).setTime(terror.get(i).getTime());
            terror.get(i).setBudget(terror.get(i).getBudget());
            terror.get(i).setGenrer(terror.get(i).getGenrer());
        }

        return terror;
    }


    public static ArrayList<Terror> modTerror(ArrayList<Terror> terror) {
        for (int i = 0; i < terror.size(); i++) {
            String opcion = Lecutra.escaneoString("Hay " + (i + 1) + " peliculas, " + "QUIERE modificar la pelicula?" + (i + 1) + " DIGITE S o N");
            if (opcion.toLowerCase(Locale.ROOT).equals("s")) {
                terror.get(i).setAdult(Lecutra.escaneoString("digite el valor de si es true o false +18"));
                terror.get(i).setOriginalLanguage(Lecutra.escaneoString("digite el valor language"));
                terror.get(i).setOriginalTitle(Lecutra.escaneoString("digite el valor title"));
                terror.get(i).setOverview(Lecutra.escaneoString("digite el valor"));
                terror.get(i).setTime(Lecutra.escaneoString("digite el valor time"));
                terror.get(i).setBudget(Lecutra.escaneoString("digite el valor BUDGET"));
                terror.get(i).setGenrer(Lecutra.escaneoString("digite el valor genrer"));

            }
        }
        return terror;
    }


    public static void obtenerTiempo(ArrayList<Terror> terror) {
        String time = null;
        String name = null;


        for (int i = 0; i < terror.size(); i++) {
            time = terror.get(i).getTime();
            name = terror.get(i).getOriginalTitle();
            System.out.println("el nombre de la pelicula es :" + name + " con duracion :" + time);
        }
    }

    public static void obtenerDescripcion(ArrayList<Terror> terror) {
        String overview = null;
        String time = null;
        String name = null;


        for (int i = 0; i < terror.size(); i++) {

            name = terror.get(i).getOriginalTitle();
            overview = terror.get(i).getOverview();
            System.out.println(("el nombre de la pelicula es :" + name + " con overviem :" + overview));
        }
    }
}
