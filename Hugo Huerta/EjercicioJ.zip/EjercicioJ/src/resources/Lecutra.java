package resources;

import java.util.Scanner;

public class Lecutra {
    public static String escaneoString(String mensaje) {
        Scanner lector = new Scanner(System.in);
        System.out.println(mensaje);
        return lector.nextLine();
    }
}
