package resources;

import models.Drama;


import java.util.ArrayList;
import java.util.Locale;

public class DramaMethods {

    public static ArrayList<Drama> addT(ArrayList<Drama> dramas) {

        for (int i = 0; i < dramas.size(); i++) {
            dramas.get(i).setAdult(dramas.get(i).getAdult());
            dramas.get(i).setOriginalLanguage(dramas.get(i).getOriginalLanguage());
            dramas.get(i).setOriginalTitle(dramas.get(i).getOriginalTitle());
            dramas.get(i).setOverview(dramas.get(i).getOverview());
            dramas.get(i).setTime(dramas.get(i).getTime());
            dramas.get(i).setBudget(dramas.get(i).getBudget());
            dramas.get(i).setGenrer(dramas.get(i).getGenrer());
        }

        return dramas;
    }


    public static ArrayList<Drama> modDrama(ArrayList<Drama> dramas) {
        for (int i = 0; i < dramas.size(); i++) {
            String opcion = Lecutra.escaneoString("Hay  + (i + 1)" +"peliculas" + "QUIERE modificar la pelicula?" + (i + 1) + " DIGITE S o N");
            if (opcion.toLowerCase(Locale.ROOT).equals("s")) {
                dramas.get(i).setAdult(Lecutra.escaneoString("digite el valor de si es true o false +18"));
                dramas.get(i).setOriginalLanguage(Lecutra.escaneoString("digite el valor language"));
                dramas.get(i).setOriginalTitle(Lecutra.escaneoString("digite el valor title"));
                dramas.get(i).setOverview(Lecutra.escaneoString("digite el valor"));
                dramas.get(i).setTime(Lecutra.escaneoString("digite el valor time"));
                dramas.get(i).setBudget(Lecutra.escaneoString("digite el valor BUDGET"));
                dramas.get(i).setGenrer(Lecutra.escaneoString("digite el valor genrer"));

            }
        }
        return dramas;
    }


    static String time = null;
    static String name = null;

    public static void obtenerTiempoDrama(ArrayList<Drama> dramas) {
        String name = null;

        for (int i = 0; i < dramas.size(); i++) {
            time = dramas.get(i).getTime();
            name = dramas.get(i).getOriginalTitle();
        }
        System.out.println((Constants.TITULO + name + " La duracion es :" + time));
    }

    public static void obtenerDescripcion(ArrayList<Drama> dramas) {
        String overview = null;


        for (int i = 0; i < dramas.size(); i++) {
            name = dramas.get(i).getOriginalTitle();
            overview = dramas.get(i).getOverview();
        }
        System.out.println((Constants.TITULO + name + Constants.OVERVIEW + overview));
    }
}
