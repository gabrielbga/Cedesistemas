package resources;

import models.Drama;
import models.Suspenso;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class SuspensoMenu {
    public static void menuSuspenso(){

        ArrayList<Suspenso> suspenso= new ArrayList<>();
        suspenso.add(new Suspenso("false", "FR", "El Hoyo", "El un futuro los prisioneros se alojan en celdas"
                , "180min", "9000000$", "Suspenso"));
        Scanner lector = new Scanner(System.in);
        System.out.println(" Selecciona una opcion ");
        boolean salir = false;
        int opcion;
        while (!salir) {
            System.out.println("1. Opcion Informacion");
            System.out.println("2. Opcion Actualizar");
            System.out.println("3. Opcion Mostrar duracion peliculas");
            System.out.println("4. Opcion Mostrar resumen pelicula");
            System.out.println("5. Opcion Recomendaciones");
            System.out.println("6. Salir");

            try {

                opcion = lector.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.println("Opcion Informacion");

                        obtenerInformacionSuspenso(SuspensoMethods.addT(suspenso));
                        break;
                    case 2:
                        System.out.println("Opcion Actualizar");
                        SuspensoMethods.modSuspenso(suspenso);
                        break;
                    case 3:
                        System.out.println("Opcion Mostrar duracion peliculas");
                        SuspensoMethods.obtenerTiempoSuspenso(suspenso);
                        break;
                    case 4:
                        System.out.println("Opcion Mostrar resumen pelicula");
                        SuspensoMethods.obtenerDescripcionSuspenso(suspenso);
                        break;
                    case 5:
                        System.out.println("Como consejo , ya que es de Suspenso debe reproducirse a 0.9x");
                        break;
                    case 6:
                        System.out.println("Salir");
                        salir = true;
                        break;
                    default:
                        System.out.println("digita los numeros entre 1 y 4");
                }
            } catch (InputMismatchException e) {
                System.out.println("Digite un numero del 1 al 4");
                lector.next();
            }
        }
    }
    public static void obtenerInformacionSuspenso(ArrayList<Suspenso> suspenso) {


        for (int i = 0; i < suspenso.size(); i++) {

                System.out.println(Constants.ADULT+suspenso.get(i).getAdult() + Constants.IDIOMA+suspenso.get(i).getOriginalLanguage() + Constants.TITULO+suspenso.get(i).getOriginalTitle()+
                        Constants.DESCRIPCION + suspenso.get(i).getOverview() + Constants.DURACION +suspenso.get(i).getTime() + Constants.PRESUPUESTO+suspenso.get(i).getBudget() + Constants.GENERO+suspenso.get(i).getGenrer());
         }
    }
}
