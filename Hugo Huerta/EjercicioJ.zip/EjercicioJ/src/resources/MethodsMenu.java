package resources;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MethodsMenu {

    public static int escaneoInt(String mensaje) {
        Scanner lector = new Scanner(System.in);
        System.out.println(mensaje);
        return lector.nextInt();

    }

    public static void menuOpciones() {
        Scanner lector = new Scanner(System.in);
        System.out.println(" Selecciona una opcion ");
        boolean salir = false;
        int opcion;
        while (!salir) {
            System.out.println("1. Opcion TERROR");
            System.out.println("2. Opcion SUSPENSO");
            System.out.println("3. Opcion COMEDIA");
            System.out.println("4. Opcion DRAMA");
            System.out.println("5. Salir");

            try {

                opcion = lector.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.println("Has seleccionado genero terror");
                        TerrorMenu.menuTerror();
                        break;
                    case 2:
                        System.out.println("Has seleccionado genero suspenso");
                        SuspensoMenu.menuSuspenso();
                        break;
                    case 3:
                        System.out.println("Has seleccionado genero comedia");
                        ComediaMenu.menuComedia();
                        break;
                    case 4:
                        System.out.println("Has seleccionado genero drama");
                        DramaMenu.menuDrama();
                        break;
                    case 5:
                        System.out.println("Has seleccionado salir");
                        salir = true;
                        break;
                    default:
                        System.out.println("digita los numeros entre 1 y 4");
                }
            } catch (InputMismatchException e) {
                System.out.println("Digite un numero del 1 al 4");
                lector.next();
            }
        }
    }
}
